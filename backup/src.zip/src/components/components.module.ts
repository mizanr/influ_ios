import { TranslateModule } from '@ngx-translate/core';
import { IonicPageModule } from 'ionic-angular';
import { ServiceComponent } from './service/service';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HeaderIconComponent } from './header-icon/header-icon';
@NgModule({
    declarations: [
        ServiceComponent,
        HeaderIconComponent
    ],
    imports: [IonicPageModule.forChild(ServiceComponent),
    TranslateModule.forChild()],
    exports: [
        ServiceComponent,
        HeaderIconComponent
    ],
    // schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class ComponentsModule { }
