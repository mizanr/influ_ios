import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AuthProvider } from '../../providers/auth/auth';
import { RestApiProvider } from '../../providers/rest-api/rest-api';

/**
 * Generated class for the HiredListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-hired-list',
  templateUrl: 'hired-list.html',
})
export class HiredListPage {
  service_id:any;
lists:any = new Array();

  constructor(public navCtrl: NavController, 
    public auth: AuthProvider, 
    public api: RestApiProvider,
    public navParams: NavParams) {
    this.service_id=navParams.data.service_id;
    console.log(this.service_id);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad HiredListPage');
  }

  ionViewWillEnter() {
    let url = `GetHiredList?job_id=${this.service_id}`;
    this.api.get({},1,url).then((res:any) => {
      console.log(res);
      if(res.status==1){
        this.lists=res.data;
      } else {
        this.lists=new Array();
      }
    })
  }

  mark_as_complete(service:any) {
    console.log(service);
    let Data = {
      id:service.jobId,
      user_id:this.auth.getCurrentUserId(),
      company_id:service.hired_by,
    }
    this.api.get(Data,1,'MarkAsComplete').then((res:any) => {
      console.log(res);
      if(res.status==1){
        this.ionViewWillEnter();
         // this.getPost(0);
      }
    })
  }

}
