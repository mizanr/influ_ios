// import { NgModule } from '@angular/core';
// import { IonicPageModule } from 'ionic-angular';
// import { RatePopupPage } from './rate-popup';
// import { StarRatingModule } from 'ionic3-star-rating';

// @NgModule({
//   declarations: [
//     RatePopupPage,
//   ],
//   imports: [
//     IonicPageModule.forChild(RatePopupPage),
//   ],
// })
// export class RatePopupPageModule {}
