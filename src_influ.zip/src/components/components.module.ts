// import { ServiceComponent } from './service/service';
// import { NgModule } from '@angular/core';
// @NgModule({
// 	declarations: [ServiceComponent],
// 	imports: [],
// 	exports: [ServiceComponent]
// })
// export class ComponentsModule {}
